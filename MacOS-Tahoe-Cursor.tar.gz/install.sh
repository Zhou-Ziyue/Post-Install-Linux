sudo cp -r /home/ziyue/下载/MacOS-Tahoe-Cursor/MacOS-Tahoe-Cursor /usr/share/icons/

sudo cp -r /home/ziyue/下载/MacOS-Tahoe-Cursor/MacOS-Tahoe-Cursor/cursors /usr/share/icons/Adwaita/
